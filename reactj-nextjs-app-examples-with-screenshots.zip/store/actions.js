// action - account reducer
export const LOGIN = 'LOGIN';
export const LOGOUT = 'LOGOUT';
export const SET_DETAILS = 'SET_DETAILS';
export const SET_PARAMS = 'SET_PARAMS';
export const SET_CURRENCY = 'SET_CURRENCY';
export const SET_BUSTER = 'SET_BUSTER';
